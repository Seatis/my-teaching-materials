package com.greenfox.services;

public interface MessageService {

    boolean sendMessage(String msg, String rec);
}