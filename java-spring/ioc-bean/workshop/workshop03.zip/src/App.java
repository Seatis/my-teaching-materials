import com.greenfox.Env;
import com.greenfox.services.*;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.greenfox.configuration.AppConfig;


public class App {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        //TextEditor te = (TextEditor) context.getBean("textEditor");
        TextEditor te = context.getBean(TextEditor.class);
        te.spellCheck("Woof");
//        Env env = new Env(te);
//        env.getTe().spellCheck("Woof");

    }
}

