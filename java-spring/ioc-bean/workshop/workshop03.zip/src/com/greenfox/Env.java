package com.greenfox;
import com.greenfox.services.*;

/**
 * Created by user on 12/22/2016.
 */
public class Env {
    public Env(TextEditor te) {
        this.te = te;
    }

    public void setTe(TextEditor te) {
        this.te = te;
    }

    public TextEditor getTe() {
        return te;
    }

    TextEditor te;




}
