package com.greenfox.configuration;

import com.greenfox.services.SpellChecker;
import com.greenfox.services.TextEditor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(value="com.greenfox.services")
public class AppConfig {

//    @Bean  //equiv to <beans><bean name="textEditor" class="com.greenfox.services.TextEditor"></beans>
    @Bean
    public TextEditor textEditor() {
        return new TextEditor();
    }

    @Bean
    public SpellChecker spellChecker() {
        return new SpellChecker();
    }
}
