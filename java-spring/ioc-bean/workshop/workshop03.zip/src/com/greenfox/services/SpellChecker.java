package com.greenfox.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SpellChecker {

    //@Autowired
    public SpellChecker(){
        System.out.println("Inside SpellChecker constructor." );
    }

    public void checkSpelling(String tx){
        System.out.printf("Inside checkSpelling, %s is a word.\n", tx );
    }

}