package com.greenfox.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TextEditor {
    private SpellChecker spellChecker;

    public TextEditor () {
        System.out.println("Inside creating a TextEditor");

    }

    @Autowired //test 1
    public void setSpellChecker( SpellChecker spellChecker ){
        this.spellChecker = spellChecker;
    }
    public SpellChecker getSpellChecker( ) {
        return spellChecker;
    }
    public void spellCheck(String tx) {
        spellChecker.checkSpelling(tx);
    }
}