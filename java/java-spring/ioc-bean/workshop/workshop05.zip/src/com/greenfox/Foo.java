package com.greenfox;
import org.springframework.stereotype.Component;

@Component
public class Foo {

    Bar bar;
    public Foo(Bar bar) {
        this.bar = bar;

    }

    public void init () {
        System.out.println("The Foo Man is awakening!");
    }

    public void cleanup () {
        System.out.println("The Foo Man is no more, and his mess is gone too!");
    }

    public String toString () { return "In Foo:" + bar.toString();}
}
