package com.greenfox;

import org.springframework.stereotype.Component;

@Component
public class Bar {

    public String toString() {return "new Bar";}
}
