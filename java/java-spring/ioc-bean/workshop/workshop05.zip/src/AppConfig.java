import com.greenfox.Bar;
import com.greenfox.Foo;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(value={"com.greenfox"})
public class AppConfig {

    @Bean(initMethod="init", destroyMethod="cleanup")
    public Foo foo() {return new Foo(bar());}

    @Bean
    public Bar bar() {return new Bar();}

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        Foo foo = (Foo) context.getBean("foo");

        System.out.println(foo.toString());

        //close the context
        context.close();

    }
}



